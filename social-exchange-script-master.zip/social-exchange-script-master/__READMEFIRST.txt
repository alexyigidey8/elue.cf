1. upload all files to your domain.

2. setup a new mysql database however you want.

3. import file db.sql into your database using phpmyadmin.

4. open config.php and type in the new database settings that you setup.

5. open your browser and load up your domain

6. login to your site as  admin/password 

7. Change your admin information and continue to adjust site as you want..

If you need any additional help or assistance , contact us!