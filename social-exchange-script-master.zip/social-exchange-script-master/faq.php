<?php
include 'header.php';
?>
<div class="contentbox">
    <div class="head">FAQ</div>
    <div class="contentinside">
        <b>(1) What is this site?</b><br/>
        This site is a Social Exchange and here you can increase your Website Traffic and Popularity.<br/><br/>
        <b>(2) What are coins?</b><br/>
        The coins are points received from your activity with other users.<br/><br/>
        <b>(3) What can I do with coins?</b><br/>
        You can exchange them for Website Traffic and Social Presence.<br/><br/>
        <b>(4) How I can earn coins?</b><br/>
        You will earn coins for every exchange from you, to our users.<br/><br/>
        <b>(5) Can I buy coins?</b><br/>
        Yes, you can buy coins. Click on "Buy coins" on the sidebar, for more info.
    </div>
</div>
<?php
include 'footer.php';
?>