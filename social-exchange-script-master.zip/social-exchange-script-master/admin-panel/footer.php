        </div>
        <div class="footer">
            Copyright &copy; 2012 <a class="footername" href="<?php echo $site->site_url; ?>"><?php echo $site->site_name; ?></a>
        </div>
    </body>
</html>